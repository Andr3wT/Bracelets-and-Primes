import csv
import math
import xlwt
#import matplotlib as plt

NAME = "bracelets"
ROWWIDTH = 20

def get_total_primes( bracelet ):
    total = 0
    i = 0
    while( i < len(bracelet) ):
        if( is_prime(bracelet[i][1]) ):
            total += 1
        i += 1
    return total

def is_prime( input ):
    if( input == 1 ):
        return False
    i = 2
    sqrt = math.sqrt( input )
    while( i <= sqrt ):
        if( input % i == 0 ):
            return False
        i += 1
    return True

def get_bracelet( input, start):
    bracelet = []

    looped = False
    curNum = start
    while( looped == False ):

        bracelet.append( [ curNum, input - curNum ] )
        if( curNum * 2 > input ):
            curNum = input - curNum
            curNum *= 2
        else:
            curNum *= 2
        
        i = 0
        while( i < len(bracelet) ):
            if( curNum == bracelet[i][0] or curNum == bracelet[i][1] ):
                looped = True
            i += 1
        
    return bracelet

def get_lowest_unused( bracelets ):
    lowest = 1
    cleanLoop = False
    while( cleanLoop == False ):
        cleanLoop = True
        i = 0
        while( i < len( bracelets ) ):
            j = 0
            while( j < len( bracelets[i] ) ):
                if( lowest in bracelets[i][j] ):
                    lowest += 2
                    cleanLoop = False
                j += 1
            i += 1
    return lowest


def get_bracelets( input ):

    if( input % 2 == 0 ):
        return 0

    bracelets = []
    totalNums = 0
    curNum = 1
    curBracelet = 0

    while( totalNums < input - 1 ):
        bracelets.append( get_bracelet( input, curNum ) )
        i = 1
        while( i <= len( bracelets[ curBracelet ] ) ):
            totalNums += 2
            i += 1
        
        curNum = get_lowest_unused( bracelets )
        curBracelet += 1
    return bracelets

def write_list_of_bracelets( listOfBracelets, name ):
    fontB = xlwt.Font()
    fontB.name = 'Arial'
    fontB.colour_index = xlwt.Style.colour_map['black']
    fontR = xlwt.Font()
    fontR.name = 'Arial'
    fontR.bold = True
    fontR.colour_index = xlwt.Style.colour_map['red']

    styleB = xlwt.XFStyle()
    styleR = xlwt.XFStyle()
    styleB.font = fontB
    styleR.font = fontR

    wb = xlwt.Workbook()
    i = 0
    while( i < len( listOfBracelets ) ):
        ws = wb.add_sheet( "Bracelet " + str( listOfBracelets[i][0] ) )
        ws.write( 0, 0, "N = " + str(listOfBracelets[i][0]), styleB )
        bracelets = listOfBracelets[i][1]
        j = 0
        #j = current bracelet
        while( j < len(bracelets) ):

            #k = Amount of numbers with charms / 2 (Divided by two because they are in pairs)
            k = len( bracelets[j] )

            #x = j % 10 (bracelets are printed in groups of 10 each. Getting the % 10 of j returns which column things should be printed on)
            y = j % ROWWIDTH

            #y = 3 + ((j/10) * k ): (3 is a constant amount the data should be moved down by for readibility; j/10: returns a number for which group of bracelets the current group is on ->  * (k + 3): multiplies the current group by the proper spacing needed)
            x = 3 + (int(j/ROWWIDTH) * (k+3) )

            #writes current bracelet header; "B" stands for bracelet
            ws.write( x - 1, y, "B"+ str(j + 1) )
            ws.write( x, y, "P: "+ str( get_total_primes( bracelets[j] ) ) )

            l = 0
            while( l < len(bracelets[j]) ):
                x += 1
                if( is_prime(bracelets[j][l][1]) == False ):
                    ws.write( x, y, str(bracelets[j][l][0])+ " " +str( bracelets[j][l][1] ), styleB )
                else:
                    ws.write( x, y, str(bracelets[j][l][0])+ " " +str( bracelets[j][l][1] ), styleR )
                l += 1
            j += 1
        i += 1
    wb.save( 'bracelets.xls')
        





option = 0
while( option == 0 ):
    print("Options:\n\t1: Get bracelets for single digit\n\t2: Get bracelets for range of digits\nPlease enter number:")
    option = input()
    if( int(option) == 0 ):
        print("Please enter a number")
        option = 0
    elif( int( option ) > 2 or int( option ) < 1 ):
        print("Please enter a valid option")
        option = 0
option = int(option)
valid = False
firstNum = 0
secondNum = 0
listOfBracelets = []

while( valid == False ):
    valid = True
    if( option == 1):
        print("Please enter your number:")
        firstNum = input()
        firstNum = int(firstNum)
        if( firstNum == 0 ):
            print("Please enter a valid number")
            valid = False
        elif( firstNum % 2 == 0 or firstNum < 0 ):
            print("Please enter an odd number greater than zero")
            valid = False
    elif( option == 2 ):
        print("Please enter your first number:")
        firstNum = input()
        firstNum = int(firstNum)
        print("Please enter your second number:")
        secondNum = input()
        secondNum = int(secondNum)
        if( firstNum == 0 or secondNum == 0 ):
            print("Please enter a valid numbers")
            valid = False
        elif( firstNum < 0 or secondNum < 0 ):
            print("Please enter numbers greater than zero")
            valid = False
        

if( option == 1 ):
    inputAndBracelets = [firstNum]
    inputAndBracelets.append( get_bracelets( firstNum ) )
    listOfBracelets.append( inputAndBracelets )

    #The following code is for printing a bracelet in the terminal; X's indicate charms with prime numbers 

    #print( listOfBracelets )
    #i = 0
    #while( i < len(listOfBracelets) ):
        #j = 0
        #numsInBracelet = 0
        #bracelets = listOfBracelets[i][1]
        #while( j < len( bracelets )):
            #k = 0
            #bracelet = bracelets[j]
            #print( "Bracelet "+ str(j) + ":" )
            #while( k < len( bracelet )):
                #numsInBracelet += 2
                #print( bracelet[k], end = "" )
                #if( is_prime(bracelet[k][1]) ):
                    #print(" X")
                #else:
                    #print("")
                #k += 1
            #j += 1
            #print( "Numbers in bracelet: "+ str( numsInBracelet ) )
        #i += 2
elif( option == 2 ):
    i = firstNum
    while( i <= secondNum ):
        if( is_prime( i ) and i != 2 ):
            inputAndBracelets = []
            inputAndBracelets.append(i)
            inputAndBracelets.append( get_bracelets( i ) )
            listOfBracelets.append( inputAndBracelets )
        i += 1
    

write_list_of_bracelets( listOfBracelets, NAME )